//app.js
App({
  onLaunch: function () {
    
  },
  globalData: {
    name: '',
    url:'',
    urls: '',
    title: '私人心情录',
    body: '',
  }
})
